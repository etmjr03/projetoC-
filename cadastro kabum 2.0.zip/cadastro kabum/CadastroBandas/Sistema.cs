﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CadastroBandas
{
    public partial class Sistema : Form
    {
        

        public Sistema()
        {
            InitializeComponent();
            
        }
        

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCadastra_Click(object sender, EventArgs e)
        {
            marcador.Height = btnCadastra.Height;
            marcador.Top = btnCadastra.Top;
            tabControl1.SelectedTab = tabControl1.TabPages[1];
            

        }

        

        private void btnBusca_Click(object sender, EventArgs e)
        {
            marcador.Height = btnBusca.Height;
            marcador.Top = btnBusca.Top;
            tabControl1.SelectedTab = tabControl1.TabPages[0];
        }

        

   


        private void btnConfirmaRemocao_Click(object sender, EventArgs e)
        {
            int linha = dgBandas.CurrentRow.Index;
            int id = Convert.ToInt32(
                    dgBandas.Rows[linha].Cells["idbandas"].Value.ToString());
            DialogResult resp = MessageBox.Show("Tem certeza que deseja excluir?",
                "Remove Banda", MessageBoxButtons.OKCancel);
            if (resp == DialogResult.OK)
            {
                ConectaBanco con = new ConectaBanco();
                bool retorno = con.deletaBanda(id);
                if (retorno == true)
                {
                    MessageBox.Show("Produto excluida com sucesso!");
                    listaDGBandas();
                }// fim if retorno true
                else
                    MessageBox.Show(con.mensagem);
            }// fim if Ok Cancela
            else
                MessageBox.Show("Exclusão cancelada");
        }

        
        private void BtnConfirmaCadastro_Click(object sender, EventArgs e)
        {
            Banda b = new Banda();
            b.Nome = txtnome.Text;
            b.Genero = txtgenero.Text;
            b.Integrantes =Convert.ToInt32(txtintegrantes.Text);
            b.Ranking = Convert.ToInt32(txtranking.Text);
            ConectaBanco con = new ConectaBanco();
            bool resp = con.insereBanda(b);
            if (resp == true)
                MessageBox.Show("Inserido :)");
            else
                MessageBox.Show(con.mensagem);
            listaDGBandas();//atualizando o grid
            limpaTela();

        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        void limpaTela()
        {
            txtnome.Clear();
            txtintegrantes.Clear();
            txtgenero.Clear();
            txtranking.Clear();

        }

        void listaDGBandas()
        {
            ConectaBanco con = new ConectaBanco();
            dgBandas.DataSource = con.listaBandas();
            dgBandas.Columns["idbandas"].Visible = false;
        }
        private void Sistema_Load(object sender, EventArgs e)
        {
            listaDGBandas();
        }

        private void TxtnomeBusca_TextChanged(object sender, EventArgs e)
        {
            (dgBandas.DataSource as DataTable).DefaultView.RowFilter = string.Format("Nome LIKE '%{0}%'", txtnomeBusca.Text);
        }
    }
}
